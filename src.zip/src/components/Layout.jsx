/* =========================================================
   App shell layout — topbar, sidebar, mobile bottom nav.
   Uses the router (NavLink/useNavigate) and renders <Outlet/>.
   ========================================================= */
import React from 'react'
import { NavLink, useNavigate, Outlet, useLocation } from 'react-router-dom'
import { Icon, Avatar, BrandMark } from './ui.jsx'
import { ToastHost, Loader } from './states.jsx'
import { DialogHost } from './Dialog.jsx'
import { ShareHost } from './ShareSheet.jsx'
import { ComposeModal } from './ComposeModal.jsx'
import { useAuth } from '../context/AuthContext.jsx'
import { api } from '../api/index.js'

const NAV = [
  { to:'/',              icon:'home',     label:'Home', end:true },
  { to:'/explore',       icon:'search',   label:'Explore' },
  { to:'/reels',         icon:'reels',    label:'Reels' },
  { to:'/qna',           icon:'qna',      label:'Q&A' },
  { to:'/research',      icon:'research', label:'Research' },
  { to:'/notifications', icon:'bell',     label:'Notifications' },
  { to:'/activity',      icon:'list',     label:'Activity' },
  { to:'/saved',         icon:'bookmark', label:'Saved' },
  { to:'/profile',       icon:'user',     label:'Profile' },
  { to:'/settings',      icon:'settings', label:'Settings' },
]

// Main pages → bottom tab bar; every page (incl. these) → the sidebar drawer.
const BOTTOM_TABS = [
  { to:'/',      icon:'home',  label:'Home', end:true },
  { to:'/reels', icon:'reels', label:'Reels' },
  { to:'/qna',   icon:'qna',   label:'Q&A' },
  { to:'/profile', icon:'user', label:'You' },
]

export function Layout() {
  const navigate = useNavigate()
  const location = useLocation()
  const { user, logout } = useAuth()
  const me = user || { full: 'You', handle: 'you', initials: 'Y', avc: 'linear-gradient(135deg,#159a76,#0a4a3c)' }
  const [composeType, setComposeType] = React.useState(null)
  const [editPost, setEditPost] = React.useState(null)
  const [search, setSearch] = React.useState('')
  const [unread, setUnread] = React.useState(0)
  const [navOpen, setNavOpen] = React.useState(false)

  // On mobile the full sidebar slides in as a left drawer (the topbar hamburger
  // opens it); the bottom bar carries the main pages.
  // Close the drawer on navigation and on Escape.
  React.useEffect(() => { setNavOpen(false) }, [location.pathname])
  React.useEffect(() => {
    if (!navOpen) return
    const onKey = (e) => { if (e.key === 'Escape') setNavOpen(false) }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
  }, [navOpen])

  // any page can open the composer by dispatching window 'ika:compose'.
  // detail is a postType string (create) OR { editPost } (edit, §6.4).
  // CRITICAL: when opening EDIT mode, always re-fetch the canonical post
  // before showing the modal. Feed items only carry `textPreview` (truncated
  // to 280 chars by POST_API §5), so if we let the modal pre-fill its
  // textarea from a feed-shape post, saving without retyping would overwrite
  // the full body with the truncated preview — silent data loss.
  React.useEffect(() => {
    const h = async (e) => {
      const d = e.detail
      if (d && typeof d === 'object' && d.editPost) {
        const seed = d.editPost
        let full = seed
        try { full = await api.posts.get(seed.id) } catch { /* fall back to seed */ }
        setEditPost(full); setComposeType('EDIT')
      } else {
        setEditPost(null); setComposeType(d || 'TEXT')
      }
    }
    window.addEventListener('ika:compose', h)
    return () => window.removeEventListener('ika:compose', h)
  }, [])

  // live unread badge: seed from /unread/count, then SET from `unread-count` SSE
  // events (absolute — never hand-increment; aggregated rows wouldn't add up).
  // Self-heals: a hard close (readyState 2 = expired token) → refresh + reopen.
  React.useEffect(() => {
    api.notifications.unreadCount().then(setUnread).catch(() => {})
    let close = null, closed = false, healing = false
    const open = () => {
      close = api.notifications.stream({
        onUnreadCount: setUnread,
        onError: async (readyState) => {
          if (closed || readyState !== 2 || healing) return   // 2 = CLOSED; 0/CONNECTING auto-reconnects
          healing = true
          try { await api.auth.refresh() } catch { /* refresh failed → leave it; RequireAuth handles 401s */ }
          close?.(); open()
          setTimeout(() => { healing = false }, 8000)
        },
      })
    }
    open()
    return () => { closed = true; close?.() }
  }, [])

  const onSearch = (e) => {
    if (e.key === 'Enter' && search.trim()) navigate('/explore?q=' + encodeURIComponent(search.trim()))
  }
  const onPublished = (post) => {
    window.dispatchEvent(new CustomEvent('ika:post-created', { detail: post }))
    navigate('/')
  }
  // edit (PATCH §6.4): patch in place, stay on the current page
  const onEdited = (post) => window.dispatchEvent(new CustomEvent('ika:post-updated', { detail: post }))
  const closeCompose = () => { setComposeType(null); setEditPost(null) }
  const signOut = async () => { await logout(); navigate('/login') }

  return (
    <div className="app">
      <header className="topbar">
        <button className="topbar-menu" onClick={() => setNavOpen(true)} aria-label="Open menu"><Icon name="menu"/></button>
        <div className="brand" onClick={() => navigate('/')} style={{ cursor:'pointer' }}>
          <div className="mark"><BrandMark/></div>
          <div>
            <div className="word">IKA<b>.</b></div>
            <small>Islamic Knowledge Archive</small>
          </div>
        </div>

        <div className="tb-search">
          <Icon name="search"/>
          <input value={search} onChange={e => setSearch(e.target.value)} onKeyDown={onSearch}
            placeholder="Search posts, research, scholars, sounds…"/>
        </div>

        <div className="tb-actions">
          <button className="icon-btn" style={{ position:'relative' }} onClick={() => navigate('/notifications')}>
            <Icon name="bell"/>{unread > 0 && <span className="dot"/>}
          </button>
          <button className="icon-btn tint" onClick={() => setComposeType('TEXT')}><Icon name="compose"/></button>
          <button className="me-chip" onClick={() => navigate('/profile')}>
            <Avatar initials={me.initials} color={me.avc} size={30} src={me.profileImage}/>
            <span className="nm">{me.full.split(' ')[0]}</span>
          </button>
        </div>
      </header>

      <aside className={'sidebar' + (navOpen ? ' open' : '')}>
        <div className="sidebar-head">
          <div className="brand">
            <div className="mark"><BrandMark/></div>
            <div><div className="word">IKA<b>.</b></div><small>Islamic Knowledge Archive</small></div>
          </div>
          <button className="icon-btn" aria-label="Close menu" onClick={() => setNavOpen(false)}><Icon name="close"/></button>
        </div>
        <nav className="nav">
          {NAV.map(n => (
            <NavLink key={n.to} to={n.to} end={n.end} onClick={() => setNavOpen(false)}
              className={({ isActive }) => 'nav-item ' + (isActive ? 'active' : '')}>
              <Icon name={n.icon}/><span>{n.label}</span>
              {n.to === '/notifications' && unread > 0 && <span className="badge">{unread}</span>}
            </NavLink>
          ))}
        </nav>

        <button className="cta-compose" onClick={() => { setNavOpen(false); setComposeType('TEXT') }}>
          <Icon name="compose" className="sm"/><span>Create</span>
        </button>

        <div className="side-section" style={{ marginTop:'auto' }}>
          <div className="you-card">
            <Avatar initials={me.initials} color={me.avc} size={40} src={me.profileImage}/>
            <div className="who">
              <div className="nm">{me.full}</div>
              <small>@{me.handle}</small>
            </div>
            <button className="icon-btn" title="Sign out" onClick={signOut}><Icon name="logout" className="sm"/></button>
          </div>
        </div>
      </aside>

      <main style={{ minWidth:0 }}>
        {/* lazy page chunks resolve here → the shell stays, only content shows the loader */}
        <React.Suspense fallback={<div className="main center"><div className="col-main"><Loader label="Loading…"/></div></div>}>
          <Outlet/>
        </React.Suspense>
      </main>

      <nav className="botnav">
        <NavLink to={BOTTOM_TABS[0].to} end className={({ isActive }) => isActive ? 'active' : ''}>
          <Icon name={BOTTOM_TABS[0].icon}/><small>{BOTTOM_TABS[0].label}</small>
        </NavLink>
        <NavLink to={BOTTOM_TABS[1].to} className={({ isActive }) => isActive ? 'active' : ''}>
          <Icon name={BOTTOM_TABS[1].icon}/><small>{BOTTOM_TABS[1].label}</small>
        </NavLink>
        <a className="mid" onClick={() => setComposeType('TEXT')} aria-label="Create">
          <span className="plus"><Icon name="compose"/></span>
        </a>
        <NavLink to={BOTTOM_TABS[2].to} className={({ isActive }) => isActive ? 'active' : ''}>
          <Icon name={BOTTOM_TABS[2].icon}/><small>{BOTTOM_TABS[2].label}</small>
        </NavLink>
        <NavLink to={BOTTOM_TABS[3].to} className={({ isActive }) => isActive ? 'active' : ''}>
          <Icon name={BOTTOM_TABS[3].icon}/><small>{BOTTOM_TABS[3].label}</small>
        </NavLink>
      </nav>

      {composeType && (
        <ComposeModal
          type={composeType === 'EDIT' ? undefined : composeType}
          editPost={composeType === 'EDIT' ? editPost : null}
          onClose={closeCompose} onPublished={onPublished} onEdited={onEdited}/>
      )}
      {navOpen && <div className="nav-scrim" onClick={() => setNavOpen(false)}/>}
      <ToastHost/>
      <DialogHost/>
      <ShareHost/>
    </div>
  )
}
